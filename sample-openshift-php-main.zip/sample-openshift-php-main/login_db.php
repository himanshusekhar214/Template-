<?php
$dbhost = getenv("MYSQL_SERVICE_HOST");
$dbuser = getenv("MYSQL_USER");
$dbpwd = getenv("MYSQL_PASSWORD");
$dbname = getenv("MYSQL_DATABASE");
$auidence = getenv("HELLO_AUDIENCE");
$message= getenv("HELLO_MESSAGE");
?>
